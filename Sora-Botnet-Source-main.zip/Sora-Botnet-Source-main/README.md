# Sora-Botnet-Source
Full source code and setup for Sora botnet. 
Private/unreleased botnet source

Author - qixy#6969

print{f"Leaked by {Author}"}
Includes scanlistener
